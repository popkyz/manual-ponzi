<?php
include 'inc/session.php';
$title = 'Transactions';
include 'inc/header.php';
include 'inc/config.php';
$username = $_SESSION['username'];
?>

<div class="content">
	<div class="container-fluid">
		<div class="row">
		<!-- PH Card -->
			<div class="col-md-12">
				<div class="card card-naav-stats">
					<div class="card-header" data-background-color="green">
						<i class="md md-add-shopping-cart"></i> TRANSACTIONS
					</div>
					<div class="card-content table-responsive">
						<table class="table table-striped">
							<thead>
								<th>Transaction ID</th>
								<th>Amount</th>
								<th>Date</th>
								<th>Sender</th>
								<th>Reciever</th>
								<th>Status</th>
							</thead>
							<tbody>
								<?php
									$get_trans = mysql_query("SELECT * FROM transaction WHERE username = '$username' OR merged_with = '$username'");
									if (!mysql_num_rows($get_trans)) {
										echo '<tr><td colspan="4">There are no transactions yet</td></tr>';
									}elseif (mysql_num_rows($get_trans)){
										while ($row = mysql_fetch_array($get_trans)) {
								?>
								<tr>
									<td><?php echo $row['id'] ?></td>
									<td>N5,000.00</td>
									<td><?php echo $row['transaction_datetime'] ?></td>
									<td><?php echo $row['username'] ?></td>
									<td><?php echo $row['merged_with'] ?></td>
									<?php
										if ($row['status'] == '1') {
									?>
									<td><span class="label label-success">Completed</span></td>
									<?php }elseif ($row['status'] == '0') {?>
									<td><span class="label label-warning">Pending</span></td>
									<?php } ?>
								</tr>
								<?php } } ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
	<!-- PH Card -->
		</div>
	</div>
</div>

<?php
include 'inc/footer.php';
?>