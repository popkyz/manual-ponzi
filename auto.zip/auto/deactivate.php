<?php
include 'inc/session.php';
include 'inc/config.php';
$username = $_SESSION['username'];
$de = mysql_query("UPDATE user SET ban = '1', ph_merge = '0', logged_in = '0' WHERE username = '$username'");
$fetch_trans = mysql_query("SELECT * FROM transaction WHERE username = '$username'");
$row = mysql_fetch_array($fetch_trans);
$m = $row['merged_with'];
$update = mysql_query("UPDATE user SET gh_merge = (gh_merge - 1) WHERE username = '$m'");
$del = mysql_query("DELETE FROM transaction WHERE username = '$username'");
session_destroy();
echo "<script>window.open('index.php','_self')</script>";
?>