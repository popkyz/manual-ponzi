<?php
session_start();
include 'inc/config.php';
$username = $_SESSION['username'];
$update_login = mysql_query("UPDATE user SET logged_in = '0' WHERE username = '$username'");
if ($update_login) {
	session_destroy();
	echo "<script>window.open('login.php','_self')</script>";
}else{
	echo "<script>alert('An error is keeping you from logging out')</script>";
}
?>