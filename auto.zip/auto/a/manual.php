<?php
include 'inc/config.php';
$id = $_GET['id'];
$merged_with = $_POST['username'];
$get_trans = mysql_query("SELECT * FROM transaction WHERE id = '$id'");
$row = mysql_fetch_array($get_trans);
$update = mysql_query("UPDATE transaction SET merged_with = '$merged_with' WHERE id = '$id'");
if ($update) {
	echo "<script>User has been merged</script>";
	echo "<script>window.open('transactions.php','_self')</script>";
}else{
	echo "<script>('Error merging user:".mysql_error()."')/script>";
	echo "<script>window.open('transactions.php','_self')</script>";
}
?>