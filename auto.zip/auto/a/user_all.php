<?php
include 'inc/session.php';
$title = 'All Users';
include 'inc/header.php';
include 'inc/config.php';
?>

<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
				<div class="card card-naav-stats">
					<div class="card-header" data-background-color="green">
						<i class="pull-right md md-account-circle md-2x"></i> All Registered Users
					</div>
					<div class="card-content">
						<table class="table table-hover">
							<thead>
								<th>Username</th>
								<th>Email</th>
								<th>Phone</th>
								<th>Registration Date</th>
								<th>Queue</th>
								<th>Ban</th>
								<th>View All</th>
							</thead>
							<tbody>
								<?php
									$get = mysql_query("SELECT * FROM user");
									if (!mysql_num_rows($get)) {
										echo '<tr><td colspan="7"><b><i>There are no registered users in the system yet.</i></b></td></tr>';
									}else{
										while($row = mysql_fetch_array($get)){
								?>
									<tr>
										<td><b><?php echo $row['username'] ?></b></td>
										<td><?php echo $row['email'] ?></td>
										<td><?php echo $row['phone'] ?></td>
										<td><?php echo $row['reg_date'] ?></td>
										<?php
											if ($row['trans_status'] == '1') {
										?>
										<td><span class="label label-success">Queued for GH</span></td>
										<?php
											}elseif ($row['trans_status'] == '0'){
										?>
										<td>
										<form method="post" action="queue.php?id=<?php echo $row['id'] ?>">
											<select name="amount" class="form-control input-sm">
												<option selected="" disabled="">Select Package</option>
												<option value="5000">&#8358;5,000</option>
												<option value="10000">&#8358;10,000</option>
												<option value="20000">&#8358;20,000</option>
												<option value="50000">&#8358;50,000</option>
											</select>
										<button name="queue" class="btn btn-info btn-xs btn-block">Queue for GH</button></td>
										</form>
										<?php } ?>

										<?php if ($row['ban'] == '0') { ?>
										<td><a href="user_ban.php?id=<?php echo $row['id'] ?>" class="btn btn-danger btn-xs"><i class="fa fa-ban"></i> Ban</a></td>
										<?php }elseif ($row['ban'] == '1') { ?>
										<td><a href="user_restore.php?id=<?php echo $row['id'] ?>" class="btn btn-success btn-xs"><i class="fa fa-undo"></i> Restore</a></td>
										<?php } ?>
										<td><a data-toggle="modal" data-target="#view<?php echo $row['id'] ?>" class="btn btn-info btn-sm"><i class="fa fa-eye"></i></a></td>
									</tr>

								<!-- View Modal -->
								<!-- Modal Core -->
									<div class="modal fade" id="view<?php echo $row['id'] ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
									  <div class="modal-dialog">
									    <div class="modal-content">
									      <div class="modal-header">
									        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
									        <h3 class="modal-title" id="myModalLabel"><?php echo $row['username'] ?></h3>
									      </div>
									      <form method="post" action="#">
										      <div class="modal-body">
										        <p>
										        	<b>Email:</b> <?php echo $row['email'] ?><br>
										        	<b>Phone:</b> <?php echo $row['phone'] ?><br>
										        	<b>Registration Date:</b> <?php echo $row['reg_date'] ?><br>
										        	<b>Bank:</b> <?php echo $row['bank'] ?><br>
										        	<b>Account Name:</b> <?php echo $row['account_name'] ?><br>
										        	<b>Account Number:</b> <?php echo $row['account_number'] ?><br>
										        	<?php
										        		if ($row['ban'] == '1') {
										        	?>
										        	<b>Status:</b> <label class="label label-danger">Banned</label><br>
										        	<?php
										        		}elseif ($row['ban'] == '0') {
										        	?>
										        	<b>Status:</b> <label class="label label-success">Active</label><br>
										        	<?php } ?>
										        	<?php
										        		if ($row['logged_in'] == '1') {
										        	?>
										        	<b>Online Status:</b> <label class="label label-success">Online</label><br>
										        	<?php
										        		}elseif ($row['logged_in'] == '0') {
										        	?>
										        	<b>Online Status:</b> <label class="label label-info">Offline</label><br>
										        	<?php } ?>
										        </p>
										      </div>
										      <div class="modal-footer">
										        <button type="button" class="btn btn-default btn-simple" data-dismiss="modal">Close</button>
										      </div>
									      </form>
									    </div>
									  </div>
									</div>
							<!-- View Modal Ends -->
								<?php
									} }
								?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<?php
include 'inc/footer.php';
?>