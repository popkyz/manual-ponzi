<?php
session_start();
if (!isset($_SESSION['username'])) {
	echo "<script>window.open('login.php','_self')</script>";
}
?>