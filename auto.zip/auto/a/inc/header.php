<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<link rel="apple-touch-icon" sizes="76x76" href="assets/img/apple-icon.png" />
	<link rel="icon" type="image/png" href="assets/img/favicon.png" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>Gainers' Lounge Admin | <?php echo $title ?></title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />

    <!-- Bootstrap core CSS     -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />

    <!--  Material Dashboard CSS    -->
    <link href="assets/css/material-dashboard.css" rel="stylesheet"/>

    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="assets/css/demo.css" rel="stylesheet" />

    <!--     Fonts and icons     -->
    <link type="text/css" rel="stylesheet" href="assets/fonts/font-awesome.min.css?1422529194" />
	<link type="text/css" rel="stylesheet" href="assets/fonts/material-design-iconic-font.min.css?1421434286" />
</head>

<body>

	<div class="wrapper">

	    <div class="sidebar" data-color="purple" data-image="assets/img/sidebar-3.jpg">
			<!--
		        Tip 1: You can change the color of the sidebar using: data-color="purple | blue | green | orange | red"

		        Tip 2: you can also add an image using data-image tag
		    -->

			<div class="logo">
				<a href="#" class="simple-text">
					<i class="md md-add-circle md-3x"></i><i class="md md-account-circle md-3x"></i>
				</a>
			</div>

	    	<div class="sidebar-wrapper">
	            <ul class="nav">
	            	<?php if ($title == 'Dashboard') { ?>
	                <li class="active">
	                <?php }else{?>
	                <li>
	                <?php } ?>
	                    <a href="index.php">
	                        <i class="md md-explore"></i>
	                        <p>Dashboard</p>
	                    </a>
	                </li>

	                <?php if ($title == 'All Users') { ?>
	                <li class="active">
	                <?php }else{?>
	                <li>
	                <?php } ?>
	                    <a href="user_all.php">
	                        <i class="md md-account-child"></i>
	                        <p>All Users</p>
	                    </a>
	                </li>

	                <?php if ($title == 'Transactions') { ?>
	                <li class="active">
	                <?php }else{?>
	                <li>
	                <?php } ?>
	                    <a href="transactions.php">
	                        <i class="md md-add-shopping-cart"></i>
	                        <p>Transactions</p>
	                    </a>
	                </li>

	                <?php if ($title == 'Feedback') { ?>
	                <li class="active">
	                <?php }else{?>
	                <li>
	                <?php } ?>
	                    <a href="feedback.php">
	                        <i class="md md-quick-contacts-mail"></i>
	                        <p>Feedback</p>
	                    </a>
	                </li>
	            </ul>
	    	</div>
	    </div>

	    <div class="main-panel">
			<nav class="navbar navbar-transparent navbar-absolute">
				<div class="container-fluid">
					<div class="navbar-header">
						<button type="button" class="navbar-toggle" data-toggle="collapse">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						<a class="navbar-brand" href="#">Admin - <?php echo $title ?></a>
					</div>
					<div class="collapse navbar-collapse">
						<ul class="nav navbar-nav navbar-right">
							<li>
								<a href="#" class="dropdown-toggle" data-toggle="dropdown">
	 							   <i class="md md-perm-identity md-2x" title="Profile"></i> Administrator
		 						</a>
		 						<li>
								<a href="logout.php">
	 							   <i class="md md-settings-power md-2x" title="logout"></i> Logout
		 						</a>
							</li>
							</li>
						</ul>
					</div>
				</div>
			</nav>
