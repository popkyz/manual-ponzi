<?php
$conn = mysql_connect('localhost','root','');
if (!$conn) {
	echo "Error Connecting to server";
}
$db = mysql_select_db("ponzi");
if (!$db) {
	mysql_query("CREATE DATABASE ponzi");
}
$user = mysql_query("CREATE TABLE IF NOT EXISTS user(
	id INT(11) AUTO_INCREMENT PRIMARY KEY,
	username VARCHAR(150) NOT NULL,
	email VARCHAR(150) NOT NULL,
	phone VARCHAR(150) NOT NULL,
	password VARCHAR(150) NOT NULL,
	reg_date VARCHAR(150) NOT NULL,
	bank VARCHAR(150) NOT NULL,
	account_name VARCHAR(150) NOT NULL,
	account_number VARCHAR(150) NOT NULL,
	ban INT(11) NOT NULL,
	logged_in INT(11) NOT NULL,
	ph_merge INT(11) NOT NULL,
	gh_merge INT(11) NOT NULL,
	ph_complete INT(11) NOT NULL,
	gh_complete INT(11) NOT NULL,
	trans_status INT(11) NOT NULL
	)");
if (!$user) {
	echo "Table <b>User</b> not created ".mysql_error();
}
$transaction = mysql_query("CREATE TABLE IF NOT EXISTS transaction(
	id INT(11) AUTO_INCREMENT PRIMARY KEY,
	transaction_type VARCHAR(150) NOT NULL,
	transaction_datetime VARCHAR(150) NOT NULL,
	username VARCHAR(150) NOT NULL,
	merged_with VARCHAR(150) NOT NULL,
	status INT(11) NOT NULL,
	del INT(11) NOT NULL
	)");
if (!$transaction) {
	echo "<b>Transaction</b> Table not created".mysql_error();
}
$admin = mysql_query("CREATE TABLE IF NOT EXISTS admin(
	id INT(11) AUTO_INCREMENT PRIMARY KEY,
	username VARCHAR(150) NOT NULL,
	password VARCHAR(150) NOT NULL,
	fullname VARCHAR(150) NOT NULL
	)");

$feedback = mysql_query("CREATE TABLE IF NOT EXISTS feedback(
	id INT(11) AUTO_INCREMENT PRIMARY KEY,
	fullname VARCHAR(150) NOT NULL,
	email VARCHAR(150) NOT NULL,
	message TEXT NOT NULL
	)");
$report = mysql_query("CREATE TABLE IF NOT EXISTS report(
	id INT(11) AUTO_INCREMENT PRIMARY KEY,
	username VARCHAR(150) NOT NULL,
	trans_id VARCHAR(150) NOT NULL,
	date_sent VARCHAR(150) NOT NULL,
	type VARCHAR(150) NOT NULL,
	message TEXT NOT NULL
	)");
// ?>