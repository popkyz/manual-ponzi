<?php
include 'inc/session.php';
$title = 'Dashboard';
include 'inc/header.php';
include 'inc/config.php';
$registered_users = mysql_query("SELECT * FROM user");
$tot_users = mysql_num_rows($registered_users);
$transactions_p = mysql_query("SELECT * FROM transaction WHERE status = '0'");
$tot_trans_pending = mysql_num_rows($transactions_p);
$transactions_c = mysql_query("SELECT * FROM transaction WHERE status = '1'");
$tot_trans_completed = mysql_num_rows($transactions_c);
$feedback = mysql_query("SELECT * FROM feedback");
$tot_feedback = mysql_num_rows($feedback);
$report = mysql_query("SELECT * FROM report");
$tot_report = mysql_num_rows($report);
?>

<div class="content">
	<div class="container-fluid">
		<div class="row">

			<!-- Registered Users Card -->
			<div class="col-md-4">
				<div class="card card-stats">
					<div class="card-header" data-background-color="purple">
						<i class="md md-account-child md-2x"></i>
					</div>
					<div class="card-content">
						<p class="category">Registered Users</p>
						<h3 class="title"><?php echo $tot_users ?></h3>
					</div>
					<div class="card-footer text-center">
						<a href="user_all.php" class="btn btn-sm btn-primary btn-block">VIEW ALL</a>
					</div>
				</div>
			</div>
			<!-- Registered Users Card -->

			<!-- Completed Transactions Card -->
			<div class="col-md-4">
				<div class="card card-stats">
					<div class="card-header" data-background-color="green">
						<i class="md md-add-circle md-2x"></i>
					</div>
					<div class="card-content">
						<p class="category">Completed Transactions</p>
						<h3 class="title"><?php echo $tot_trans_completed ?></h3>
					</div>
					<div class="card-footer text-center">
						<a href="transactions.php" class="btn btn-sm btn-success btn-block">VIEW TRANSACTIONS</a>
					</div>
				</div>
			</div>
			<!-- Completed Transactions Card -->

			<!-- Pending Transactions Card -->
			<div class="col-md-4">
				<div class="card card-stats">
					<div class="card-header" data-background-color="orange">
						<i class="md md-remove-circle md-2x"></i>
					</div>
					<div class="card-content">
						<p class="category">Pending Transactions</p>
						<h3 class="title"><?php echo $tot_trans_pending ?></h3>
					</div>
					<div class="card-footer text-center">
						<a href="transactions.php" class="btn btn-sm btn-warning btn-block">VIEW TRANSACTIONS</a>
					</div>
				</div>
			</div>
			<!-- Pending Transactions Card -->

			<!-- Feedback Card -->
			<div class="col-md-4">
				<div class="card card-stats">
					<div class="card-header" data-background-color="purple">
						<i class="md md-quick-contacts-mail md-2x"></i>
					</div>
					<div class="card-content">
						<p class="category">Feedback</p>
						<h3 class="title"><?php echo $tot_feedback ?></h3>
					</div>
					<div class="card-footer text-center">
						<a href="feedback.php" class="btn btn-sm btn-primary btn-block">VIEW FEEDBACKS</a>
					</div>
				</div>
			</div>
			<!-- Feedback Card -->
		</div>
	</div>
</div>

<?php
include 'inc/footer.php';
?>