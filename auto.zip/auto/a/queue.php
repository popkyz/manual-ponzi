<?php
include 'inc/session.php';
include 'inc/config.php';
$id = $_GET['id'];
$amount = $_POST['amount'];
$action = mysql_query("UPDATE user SET trans_status = '1', gh_merge = '0', ph_merge = '0', gh_complete = '0', ph_complete = '0', recent_amount = '$amount' WHERE id = '$id'");
if ($action) {
	echo "<script>alert('User has been queued for GH')</script>";
	echo "<script>window.open('user_all.php','_self')</script>";
}else{
	echo "<script>alert('".mysql_error()."')</script>";
	echo "<script>window.open('user_all.php','_self')</script>";
}
?>