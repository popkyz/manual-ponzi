<?php
include 'inc/session.php';
$title = 'Transactions';
include 'inc/header.php';
include 'inc/config.php';
?>

<div class="content">
	<div class="container-fluid">
		<div class="row">
		<!-- PH Card -->
			<div class="col-md-12">
				<div class="card card-naav-stats">
					<div class="card-header" data-background-color="purple">
						<i class="md md-add-shopping-cart"></i> TRANSACTIONS
					</div>
					<div class="card-content table-responsive">
						<table class="table table-striped">
							<thead>
								<th>Transaction ID</th>
								<th>Amount</th>
								<th>Date</th>
								<th>Sender</th>
								<th>Reciever</th>
								<th>Auto Merge</th>
								<th>Manual Merge</th>
								<th>Status</th>
							</thead>
							<tbody>
								<?php
									$get_trans = mysql_query("SELECT * FROM transaction ORDER BY id DESC");
									if (!mysql_num_rows($get_trans)) {
										echo '<tr><td colspan="6">There are no transactions yet</td></tr>';
									}elseif (mysql_num_rows($get_trans)){
										while ($row = mysql_fetch_array($get_trans)) {
											$amount = $row['amount'];
								?>
								<tr>
									<td><?php echo $row['id'] ?></td>
									<td>&#8358;<?php echo $amount ?>.00</td>
									<td><?php echo $row['transaction_datetime'] ?></td>
									<td><?php echo $row['username'] ?></td>
									<?php
										if ($row['merged_with'] == '') {
									?>
									<td><b><i>User have not been merged</i></b></td>
									<td><a href="merge.php?id=<?php echo $row['id'] ?>" class="btn btn-sm btn-info">Auto Merge User</a></td>
									<td><form method="post" action="manual.php?id=<?php echo $row['id'] ?>">
											<select name="username" class="form-control input-sm">
												<option selected="" disabled="">Select User</option>
												<?php
													$check_users = mysql_query("SELECT * FROM user WHERE recent_amount = '$amount' AND trans_status = '1' AND gh_merge < '2' AND ban = '0' ORDER BY rand() LIMIT 1");
													if (!mysql_num_rows($check_users)) {
														echo "<option>There are no users for that amount</option>";
													}else{
														while ($row_users = mysql_fetch_array($check_users)) {
												?>
													<option value="<?php echo $row_users['username'] ?>"><?php echo $row_users['username'] ?></option>
												<?php }  }?>
											</select>
										<button name="submit" class="btn btn-info btn-xs btn-block">Merge</button></td></td>
									<?php
										}else{
									?>
									<td><?php echo $row['merged_with'] ?></td>
									<td></td>
									<td></td>
									<?php } ?>
									<?php
										if ($row['status'] == '1') {
									?>
									<td><span class="label label-success">Completed</span></td>
									<?php }elseif ($row['status'] == '0') {?>
									<td><span class="label label-warning">Pending</span></td>
									<?php } ?>
								</tr>
								<?php } } ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
	<!-- PH Card -->
		</div>
	</div>
</div>

<?php
include 'inc/footer.php';
?>