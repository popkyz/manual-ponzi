<?php
include 'inc/session.php';
$title = 'Feedback';
include 'inc/header.php';
include 'inc/config.php';
?>

<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
				<div class="card card-naav-stats">
					<div class="card-header" data-background-color="purple">
						<i class="pull-right md md-account-circle md-2x"></i> Feedback
					</div>
					<div class="card-content">
						<table class="table table-hover">
							<thead>
								<th>Username</th>
								<th>Email</th>
								<th>Message</th>
							</thead>
							<tbody>
								<?php
									$get = mysql_query("SELECT * FROM feedback ORDER BY id DESC");
									if (!mysql_num_rows($get)) {
										echo '<tr><td colspan="7"><b><i>There are no Feebacks in the system yet.</i></b></td></tr>';
									}else{
										while($row = mysql_fetch_array($get)){
								?>
									<tr>
										<td><b><?php echo $row['fullname'] ?></b></td>
										<td><?php echo $row['email'] ?></td>
										<td><?php echo $row['message'] ?></td>
									</tr>
								<?php
									} }
								?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<?php
include 'inc/footer.php';
?>