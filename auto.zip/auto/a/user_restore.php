<?php
include 'inc/session.php';
include 'inc/config.php';
$id = $_GET['id'];
$de = mysql_query("UPDATE user SET ban = '0' WHERE id = '$id'");
echo "<script>window.open('user_all.php','_self')</script>";
?>