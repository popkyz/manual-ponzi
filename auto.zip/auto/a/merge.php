<?php
include 'inc/config.php';
$id = $_GET['id'];
$get_trans = mysql_query("SELECT * FROM transaction WHERE id = '$id'");
$row = mysql_fetch_array($get_trans);
$amount = $row['amount'];
$fetch_trans = mysql_query("SELECT * FROM user WHERE recent_amount = '$amount' AND trans_status = '1' AND gh_merge < '2' AND ban = '0' ORDER BY rand() LIMIT 1");
if (!mysql_num_rows($fetch_trans)) {
	echo "<script>alert('There is no user on the Get Help Queue for that amount')</script>";
	echo "<script>window.open('transactions.php','_self')</script>";
}else{
	$row = mysql_fetch_array($fetch_trans);
	$merged_with = $row['username'];
	$update = mysql_query("UPDATE transaction SET merged_with = '$merged_with' WHERE id = '$id'");
	if ($update) {
		echo "<script>User has been merged</script>";
		echo "<script>window.open('transactions.php','_self')</script>";
	}else{
		echo "<script>('Error merging user:".mysql_error()."')/script>";
		echo "<script>window.open('transactions.php','_self')</script>";
	}
}
?>