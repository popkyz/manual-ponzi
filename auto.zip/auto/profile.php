<?php
include 'inc/session.php';
include 'inc/config.php';
$title = 'Profile';
include 'inc/header.php';
$username = $_SESSION['username'];
$get_account = mysql_query("SELECT * FROM user WHERE username = '$username'");
$row = mysql_fetch_array($get_account);
?>

<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
				<div class="card card-stats">
					<div class="card-header" data-background-color="green">
						<i class="fa fa-user"></i>
					</div>
					<div class="card-content">
					<h4 class="title">Profile</h4>
					<p class="category">Change the neccesary fields you wish to change</p>
						<form method="post" action="#">
							<div class="form-group label-floating has-success">
								<label class="control-label">Username (Readonly)</label>
								<input type="text" name="username" class="form-control" readonly="" value="<?php echo $row['username'] ?>">
							</div>
							<div class="form-group label-floating has-success">
								<label class="control-label">Email (Readonly)</label>
								<input type="email" name="username" class="form-control" readonly="" value="<?php echo $row['email'] ?>">
							</div>
							<div class="form-group label-floating has-success">
								<label class="control-label">Phone</label>
								<input type="text" name="phone" class="form-control" value="<?php echo $row['phone'] ?>">
							</div>
							<div class="form-group label-floating has-success">
								<label class="control-label">Bank</label>
								<input type="text" name="bank" class="form-control" value="<?php echo $row['bank'] ?>">
							</div>
							<div class="form-group label-floating has-success">
								<label class="control-label">Account Name</label>
								<input type="text" name="account_name" class="form-control" value="<?php echo $row['account_name'] ?>">
							</div>
							<div class="form-group label-floating has-success">
								<label class="control-label">Account Number</label>
								<input type="text" name="account_number" class="form-control" value="<?php echo $row['account_number'] ?>">
							</div>
							<center>
								<button name="submit" class="btn btn-success">Effect Changes <i class="fa fa-check-square-o"></i></button>
							</center>
						</form>
						<?php
							if (isset($_POST['submit'])) {
								$phone = $_POST['phone'];
								$account_name = $_POST['account_name'];
								$account_number = $_POST['account_number'];
								$bank = $_POST['bank'];
								$update = mysql_query("UPDATE user SET phone = '$phone', account_name = '$account_name', account_number = '$account_number', bank = '$bank' WHERE username = '$username'");
								if ($update) {
									echo "<script>alert('Your account has been updated')</script>";
									echo "<script>window.open('profile.php','_self')</script>";
								}else{
									echo "<script>alert('Error updating your account')</script>";
									echo "<script>window.open('profile.php','_self')</script>";
								}
							}
						?>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<?php
include 'inc/footer.php';
?>