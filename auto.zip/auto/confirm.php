<?php
include 'inc/session.php';
include 'inc/config.php';
$username = $_SESSION['username'];
$user = $_GET['user'];
$update_trans = mysql_query("UPDATE transaction SET status = '1' WHERE username = '$user'");
$update_user = mysql_query("UPDATE user SET trans_status = '1', ph_merge = '0' WHERE username = '$user'");
$update_me = mysql_query("UPDATE user SET gh_complete = (gh_complete + 1) WHERE username = '$username'");
$get_completed = mysql_query("SELECT * FROM user WHERE username = '$username'");
$row = mysql_fetch_array($get_completed);
if ($row['gh_complete'] == '2') {
	// Updating the transaction status
	$update_trans_stat = mysql_query("UPDATE user SET trans_status = '0', gh_merge = '0', gh_complete = '0' WHERE username = '$username'");
}
if ($update_trans && $update_user && $update_me) {
	echo "<script>alert('Payment Confirmed')</script>";
	echo "<script>window.open('index.php','_self')</script>";
}else{
	echo "<script>alert('Error confirming Payment: ".mysql_error()."')</script>";
	echo "<script>window.open('index.php','_self')</script>";
}
?>