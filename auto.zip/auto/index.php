<?php
include 'inc/session.php';
include 'inc/config.php';
$title = 'Dashboard';
include 'inc/header.php';
$username = $_SESSION['username'];
?>

<div class="content">
	<div class="container-fluid">
		<div class="row">

		<?php
		// Checking if transaction status is for PH or GH
			$check_status = mysql_query("SELECT * FROM user WHERE username = '$username'");
			$row_c = mysql_fetch_array($check_status);
			if ($row_c['trans_status'] == '0') { //If it is for PH
				// Check if there is any transaction
				$check_transactions = mysql_query("SELECT * FROM transaction WHERE username = '$username' AND status = '0'");
				if (mysql_num_rows($check_transactions)) { //If there is fetch it
					$row_merg = mysql_fetch_array($check_transactions);
				if ($row_merg['merged_with'] == '') { ?>
				<div class="col-md-12">
					<div class="alert alert-success alert-with-icon">
					<i data-notify="icon" class="fa fa-refresh fa-spin"></i>
						You have subscribed for <b>&#8358;<?php echo $row_merg['amount'] ?></b>, Please wait to be merged. To contact the administrator <a href="feedback.php"><b>Click Here</b></a>
					</div>	
				</div>
				<?php
					}elseif ($row_merg['merged_with'] != ''){
						$merged_with = $row_merg['merged_with'];
						// $expire_time = $row_merg['expire'];
						$deactivatelink = 'deactivate.php?username='.$username;
						$fetch_user_data = mysql_query("SELECT * FROM user WHERE username = '$merged_with'");
						$row_u = mysql_fetch_array($fetch_user_data);
						// Displaying the transaction
		?>
		<!-- PH Card -->
			<div class="col-md-5">
				<div class="card card-naav-stats">
					<div class="card-header" data-background-color="red">
						<i class="md md-send pull-right md-2x"></i> Choose an Option
					</div>
					<div class="card-content">
						<center>
							<h4 class="title">@<?php echo $row_u['username'] ?></h4>
							<p class="category"><b>Account Name:</b> <?php echo $row_u['account_name'] ?><br>
							<b>Account Number:</b> <?php echo $row_u['account_number'] ?><br>
							<b>Bank:</b> <?php echo $row_u['bank'] ?><br>
							<b>Touch to call:</b> <a href="tel:<?php echo $row_u['phone'] ?>"><b><?php echo $row_u['phone'] ?></b></a><br>
							<b>Amount: </b> N5,000.00 <br>
								<form method="post" action="uploadpop.php?id=<?php echo $row_merg['id'] ?>" enctype="multipart/form-data">
									<div class="form-group">
										<label for="img"><b>Click here to select your POP</b></label>
										<input type="file" id="img" name="img" class="form-control">
									</div>
									<button class="btn btn-success btn-sm btn-block">Upload</button>
								</form>
							</p>
						You have&nbsp; <span class="label label-info label-lg" id="demo"></span>&nbsp; to complete the transaction
						</center>
					</div>
					<div class="card-footer text-center">
						<a href="deactivate.php" class="btn btn-danger btn-sm btn-block">I can't pay</a>
					</div>
				</div>
			</div>
	<!-- PH Card -->
<script>
// Set the date we're counting down to
var countDownDate = new Date("<?php echo $expire_time ?>").getTime();

// Update the count down every 1 second
var x = setInterval(function() {

  // Get todays date and time
  var now = new Date().getTime();

  // Find the distance between now an the count down date
  var distance = countDownDate - now;

  // Time calculations for days, hours, minutes and seconds
  var days = Math.floor(distance / (1000 * 60 * 60 * 24));
  var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  var seconds = Math.floor((distance % (1000 * 60)) / 1000);

  // Display the result in the element with id="demo"
  document.getElementById("demo").innerHTML = days + "d " + hours + "h "
  + minutes + "m " + seconds + "s ";

  // If the count down is finished, write some text 
  if (distance < 0) {
    clearInterval(x);
    // document.getElementById("demo").innerHTML = "EXPIRED";
    window.open('deactivate.php','_self');
  }
}, 1000);
</script>
	<?php
	}
	}elseif (!mysql_num_rows($check_transactions)){ ?>

		<!-- PH Card -->
			<div class="col-md-10 col-md-offset-1">
				<div class="card card-naav-stats">
					<div class="card-header" data-background-color="blue">
						<i class="md md-account-balance-wallet pull-right md-2x"></i> SELECT PACKAGE
					</div>
					<form method="post" action="#">
						<div class="card-content">
							<div class="form-group">
								<select class="form-control" name="amount">
									<option selected="" disabled="">Select Package</option>
									<option value="5000">&#8358;5,000</option>
									<option value="10000">&#8358;10,000</option>
									<option value="20000">&#8358;20,000</option>
									<option value="50000">&#8358;50,000</option>
								</select>
							</div>
						</div>
						<div class="card-footer text-center">
							<button name="subscribe" class="btn btn-info text-center">Subscribe to Package</button>
						</div>
					</form>

					<?php
						if (isset($_POST['subscribe'])) {
							$amount = $_POST['amount'];
							$transaction_datetime = date("j F Y. h:iA");
							$username = $_SESSION['username'];
							if ($amount == '') {
								echo "<script>alert('You must select a package')</script>";
							}else{
							$insert_trans = mysql_query("INSERT INTO transaction(amount,transaction_datetime,username)VALUES('$amount','$transaction_datetime','$username')");
							$update_amount = mysql_query("UPDATE user recent_amount = '$amount' WHERE username = '$username'");
							if ($insert_trans && $update_amount) {
								echo "<script>alert('You have subscribed successfully. Please wait to be merged')</script>";
								echo "<script>window.open('index.php','_self')</script>";
							}else{
								echo "<script>alert('There was an error: ".mysql_error()."')</script>";
								echo "<script>window.open('index.php','_self')</script>";
							}
						}
						}
					?>
				</div>
			</div>
	<!-- PH Card -->
	<script>
// Set the date we're counting down to
var countDownDate = new Date("<?php echo $expire_time; ?>").getTime();

// Update the count down every 1 second
var x = setInterval(function() {

  // Get todays date and time
  var now = new Date().getTime();

  // Find the distance between now an the count down date
  var distance = countDownDate - now;

  // Time calculations for days, hours, minutes and seconds
  var days = Math.floor(distance / (1000 * 60 * 60 * 24));
  var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  var seconds = Math.floor((distance % (1000 * 60)) / 1000);

  // Display the result in the element with id="demo"
  document.getElementById("demo").innerHTML = days + "d " + hours + "h "
  + minutes + "m " + seconds + "s ";

  // If the count down is finished, write some text 
  if (distance < 0) {
    clearInterval(x);
    // document.getElementById("demo").innerHTML = "EXPIRED";
    window.open('deactivate.php','_self');
  }
}, 1000);
</script>
	<?php
	}
	}elseif ($row_c['trans_status'] == '1') {
		$check_transaction = mysql_query("SELECT * FROM transaction WHERE merged_with = '$username' AND status = '0'");
				if (mysql_num_rows($check_transaction)) { //If there is fetch it
					while ($row_tr = mysql_fetch_array($check_transaction)) {
						$merged_with = $row_tr['username'];
						$fetch_user_data = mysql_query("SELECT * FROM user WHERE username = '$merged_with'");
						$row_us = mysql_fetch_array($fetch_user_data);
						// Displaying the transaction
		?>
	<!-- GH Card -->
			<div class="col-md-5">
				<div class="card card-naav-stats">
					<div class="card-header" data-background-color="green">
						<i class="md md-reply-all pull-right md-2x"></i> INCOMING FUND
					</div>
					<div class="card-content">
						<center>
							<h4 class="title">@<?php echo $row_us['username'] ?></h4>
							<p class="category"><b>Touch to call: <a href="tel:08069275919"><?php echo $row_us['phone'] ?></a></b><br>
							<b>Amount: </b> N5,000.00 <br>
							</p>
						</center>
					</div>
					<div class="card-footer">
						<?php
							if ($row_tr['pop_img'] == '') {
						?>
						<b>No POP Uploaded Yet</b>
						<?php
							}else{
						?>
						<a href="uploads/<?php echo $row_tr['pop_img'] ?>" class="btn btn-info btn-sm btn-block">View POP</a>
						<?php } ?>
						<a href="confirm.php?user=<?php echo $row_us['username'] ?>" class="btn btn-success btn-sm btn-block">Confirm Payment</a>
					</div>
				</div>
			</div>
<!-- GH Card -->

<?php } 
}elseif (!mysql_num_rows($check_transaction)) {
?>
<div class="col-md-12">
	<div class="alert alert-success alert-with-icon">
	<i data-notify="icon" class="fa fa-refresh fa-spin"></i>
		Please wait a while the system merges you to get help. To send a message to the Administrator <a href="feedback.php"><b>Click Here</b></a>
	</div>	
</div>
<?php } } ?>
	<!-- Balance Card -->
<div class="col-md-12">
	<div class="card card-stats">
		<div class="card-header" data-background-color="orange">
			<i class="md-local-atm md-2x"></i>
		</div>
		<div class="card-content">
			<p class="category">Incoming Balance</p>
			<?php
				$ch = mysql_query("SELECT * FROM transaction WHERE merged_with = '$username' AND status = '0'");
				if (mysql_num_rows($ch)) {
				$balance = mysql_num_rows($ch);
				$balance = $balance * 5;
			?>
			<h3 class="title">N<?php echo $balance ?>,000.00</h3>
			<?php
				}elseif (!mysql_num_rows($ch)) {
			?>
			<h3 class="title">N0,000.00</h3>
			<?php } ?>
		</div>
		<div class="card-footer text-center">
			<a href="" class="btn btn-sm btn-warning btn-block">Withdraw</a>
		</div>
</div>
	</div>
		</div>
	</div>
</div>	

<?php
include 'inc/footer.php';
?>