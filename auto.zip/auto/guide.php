<?php
$title = 'Guide';
?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<link rel="apple-touch-icon" sizes="76x76" href="assets/img/my-favicon.png">
	<link rel="icon" type="image/png" href="assets/img/my-favicon.png">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>Gainers' Lounge | <?php echo $title ?></title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />

	<!--     Fonts and icons     -->
	<!-- <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons" />
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700" />
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" /> -->
	<link type="text/css" rel="stylesheet" href="assets/fonts/font-awesome.min.css?1422529194" />
	<link type="text/css" rel="stylesheet" href="assets/fonts/material-design-iconic-font.min.css?1421434286" />

	<!-- CSS Files -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="assets/css/material-kit.css" rel="stylesheet"/>

</head>

<body class="signup-page">
	<nav class="navbar navbar-transparent navbar-absolute">
    	<div class="container">
        	<!-- Brand and toggle get grouped for better mobile display -->
        	<div class="navbar-header">
        		<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigation-example">
            		<span class="sr-only">Toggle navigation</span>
		            <span class="icon-bar"></span>
		            <span class="icon-bar"></span>
		            <span class="icon-bar"></span>
        		</button>
        		<a class="navbar-brand" href="index.php"><img src="assets/img/my-icon.png" class="img img-responsive" width="35"></a>
        	</div>

        	<div class="collapse navbar-collapse" id="navigation-example">
        		<ul class="nav navbar-nav navbar-right">
    				<li>
    					<a href="login.php">
    						Login
    					</a>
    				</li>
		            <li>
		                <a href="https://t.me/codedemon" target="_blank">
							<i class="fa fa-paper-plane"></i> Telegram Us
						</a>
		            </li>
        		</ul>
        	</div>
    	</div>
    </nav>

    <div class="wrapper">
		<div class="header header-filter" style="background-image: url('assets/img/bg.jpg'); background-size: cover; background-position: top center;">
			<div class="container">
				<div class="row">
					<div class="col-md-10 col-md-offset-1 col-sm-8 col-sm-offset-2">
						<div class="card card-signup">
								<div class="header header-primary text-center">
									<h4>GUIDE TO GAINERS' LOUNGE</h4>
								</div>
								<div class="content">
								<p>
									<blockquote align="justify">
										1. Register. Enter your correct bio-data in the registration form provided on the <a href="login.php"><b>Login Page</b></a>, and click on register to complete registration, Then log in to your account with the details you provided <br><br>
										2. Send Fund. You will be merged with someone immediately you login to send fund to the person. <br><br>
										3. Upon completion/confirmation of sending of the fund, you will be merged within 2 hours to get 100% extra of the fund you sent. <br><br>
										4. After confirming payments from different users, you will immediately merged again to pay someone else. <br> <br>
										5. Continue the process and keep the enjoyment real. <br> <br>

										<b>Note: </b>Don't forget to invite others...
									</blockquote>
								</p>
								</div>
								<div class="footer text-center">
									<a href="login.php" class="btn btn-primary btn-md"><i class="md md-reply-all"></i> Back to Home</a>
								</div>
						</div>
					</div>
				</div>
			</div>

			<!-- Registration Modal -->
				<!-- Modal Core -->
					<div class="modal fade" id="register" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
					  <div class="modal-dialog">
					    <div class="modal-content">
					      <div class="modal-header">
					        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					        <h4 class="modal-title" id="myModalLabel">Register Here</h4>
					      </div>
					      <form method="post" action="#">
						      <div class="modal-body">
						        <div class="form-group">
						        	<input type="text" name="username" placeholder="Enter Username" class="form-control" required>
						        </div>
						        <div class="form-group">
						        	<input type="email" name="email" placeholder="Enter Email Address" class="form-control" required>
						        </div>
						        <div class="form-group">
						        	<input type="password" name="password" placeholder="Enter Password" class="form-control" required>
						        </div>
						        <div class="form-group">
						        	<input type="password" name="c_password" placeholder="Confirm Password" class="form-control" required>
						        </div>
						        <div class="form-group">
						        	<input type="text" name="account_name" placeholder="Account Name" class="form-control" required>
						        </div>
						        <div class="form-group">
						        	<input type="text" name="account_number" placeholder="Account Number" class="form-control" required>
						        </div>
						        <div class="form-group">
						        	<select class="form-control" name="bank">
							            <option selected="" disabled="">Select Bank</option>
							            <option>Access Bank</option>
							            <option>Citibank</option>
							            <option>Diamond Bank</option>
							            <option>Dynamic Standard Bank</option>
							            <option>Ecobank Nigeria</option>
							            <option>Fidelity Bank Nigeria</option>
							            <option>First Bank of Nigeria</option>
							            <option>First City Monument Bank</option>
							            <option>Guaranty Trust Bank</option>
							            <option>Heritage Bank Plc.</option>
							            <option>Keystone Bank Limited</option>
							            <option>Providus Bank Plc</option>
							            <option>Skye Bank </option>
							            <option>Stanbic IBTC Bank Nigeria Limited</option>
							            <option>Standard Chartered Bank</option>
							            <option>Sterling Bank</option>
							            <option>Suntrust Bank Nigeria Limited</option>
							            <option>Union Bank of Nigeria</option>
							            <option>United Bank for Africa</option>
							            <option>Unity Bank Plc.</option>
							            <option>Wema Bank</option>
							            <option>Zenith Bank</option>
							          </select>
						        </div>
						      </div>
						      <div class="modal-footer">
						        <button type="button" class="btn btn-default btn-simple" data-dismiss="modal">Close</button>
						        <button type="button" class="btn btn-info btn-simple">Save</button>
						      </div>
					      </form>
					    </div>
					  </div>
					</div>
			<!-- Registration Modal Ends -->

			<footer class="footer">
		        <div class="container">
		            <nav class="pull-left">
						<ul>
							<li><a href=""><i class="fa fa-paper-plane"></i> Telegram us</a></li>
						</ul>
		            </nav>
		            <div class="copyright pull-right">
		                &copy; 2017 <a href="index.php"><b>Gainers' Lounge</b></a>
		            </div>
		        </div>
		    </footer>

		</div>

    </div>


</body>
	<!--   Core JS Files   -->
	<script src="assets/js/jquery.min.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>
	<script src="assets/js/material.min.js"></script>

	<!--  Plugin for the Sliders, full documentation here: http://refreshless.com/nouislider/ -->
	<script src="assets/js/nouislider.min.js" type="text/javascript"></script>

	<!--  Plugin for the Datepicker, full documentation here: http://www.eyecon.ro/bootstrap-datepicker/ -->
	<script src="assets/js/bootstrap-datepicker.js" type="text/javascript"></script>

	<!-- Control Center for Material Kit: activating the ripples, parallax effects, scripts from the example pages etc -->
	<script src="assets/js/material-kit.js" type="text/javascript"></script>

</html>
