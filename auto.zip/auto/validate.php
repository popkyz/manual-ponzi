<?php
session_start();
include 'inc/config.php';
$username = $_POST['uname'];
$password = $_POST['pword'];
$password = md5($password);
$check = mysql_query("SELECT * FROM user WHERE username = '$username' AND password = '$password' AND ban = '0'");
if (mysql_num_rows($check)) {
	$update_login = mysql_query("UPDATE user SET logged_in = '1' WHERE username = '$username'");
	$_SESSION['username'] = $username;
	echo "<script>window.open('index.php','_self')</script>";
}else{
	echo "<script>alert('Incorrect Login Details')</script>";
	echo "<script>window.open('login.php','_self')</script>";
}
?>