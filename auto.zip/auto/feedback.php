<?php
include 'inc/session.php';
$title = 'Feedback';
include 'inc/header.php';
include 'inc/config.php';
$username = $_SESSION['username'];
$get_it = mysql_query("SELECT * FROM user WHERE username = '$username'");
$row = mysql_fetch_array($get_it);
?>

<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
				<div class="card card-naav-stats">
					<div class="card-header" data-background-color="green">
						<i class="md md-add-box pull-right md-2x"></i> COMPOSE
					</div>
					<div class="card-content">
						<form method="post" action="#">
							<textarea class="form-control" name="message" placeholder="Message to Admin" required="" rows="4"></textarea>
							<button name="submit" class="btn btn-success btn-block"><b>SEND</b></button>
						</form>
						<?php
							if (isset($_POST['submit'])) {
								$message = $_POST['message'];
								$fullname = $row['username'];
								$email = $row['email'];
								$insert = mysql_query("INSERT INTO feedback(fullname,message,email)VALUES('$fullname','$message','$email')");
								if ($insert) {
									echo "<script>alert('Your message has been sent, Thank you for contacting support')</script>";
									echo "<script>window.open('feedback.php','_self')</script>";
								}else{
									echo "<script>alert('There was an error encountered when sending your message')</script>";
									echo "<script>window.open('feedback.php','_self')</script>";
								}
							}
						?>
					</div>
				</div>
			</div>
		
			<div class="col-md-12">
				<div class="card card-naav-stats">
					<div class="card-header" data-background-color="green">
						<i class="md md-mail pull-right md-2x"></i> ALL MESSAGES
					</div>
					<div class="card-content">
						<?php
							$email = $row['email'];
							$get_feedback = mysql_query("SELECT * FROM feedback WHERE email = '$email' ORDER BY id DESC");
							if (!mysql_num_rows($get_feedback)) {
								echo '<h4 class="title"><b>There are no Feedbacks yet</b></h4>';
							}else{
							while ($row_feed = mysql_fetch_array($get_feedback)) {
						?>

						<h4 class="title"><b><?php echo $row_feed['fullname'] ?></b></h4>
						<blockquote><?php echo $row_feed['message'] ?></blockquote>
						<hr>
						<?php
							} }
						?>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
include 'inc/footer.php';
?>