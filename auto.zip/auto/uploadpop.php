<?php
include 'inc/session.php';
include 'inc/config.php';
$id = $_GET['id'];
		$transaction_id = $_GET['id'];
		$img = $_FILES["img"]["name"];
    $target_dir = "uploads/";
    $target_file = $target_dir.basename($_FILES["img"]["name"]);
      $uploadOK = 1;
      $imageFileType = pathinfo($target_file, PATHINFO_EXTENSION);
      $check = getimagesize($_FILES["img"]["tmp_name"]);
      if (file_exists($target_file)) {
        echo "<script>alert('Sorry, file already exists.')</script>";
        $uploadOK = 0;
      }
      // check file size
      if ($_FILES["img"]["size"] > 5000000) {
        echo "<script>alert('Sorry, your file is too large')</script>";
        $uploadOK = 0;
      }
      // Allow certain file formats
      if ($imageFileType != "jpeg" && $imageFileType != "gif" && $imageFileType != "bmp" && $imageFileType != "jpg" && $imageFileType != "png") {
        echo "<script>alert('Sorry, only JPG, JPEG, PNG,  & GIF files are allowed.')</script>";
        $uploadOK = 0;
      }
      if ($uploadOK == 0) {
        echo "<script>alert('Sorry, your file was not uploaded!')</script>";
      }else{
        move_uploaded_file($_FILES["img"]["tmp_name"], $target_file);
        // $upload_pop = mysql_query("UPDATE merge SET pop_img = '$img' WHERE transaction_id = '$transaction_id'");
$upload_pop = mysql_query("UPDATE transaction set pop_img = '$img' WHERE id = '$id'");
        if ($upload_pop) {
        	echo "<script>alert('POP has been uploaded')</script>";
        	echo "<script>window.open('index.php','_self')</script>";
        }else{
        	echo "<script>alert('Error Uploading POP')</script>";
        	echo "<script>window.open('index.php','_self')</script>";
        }
    }
?>